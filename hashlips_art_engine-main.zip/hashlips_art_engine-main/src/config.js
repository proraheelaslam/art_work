const basePath = process.cwd();
const { MODE } = require(`${basePath}/constants/blend_mode.js`);
const { NETWORK } = require(`${basePath}/constants/network.js`);
const layersDir = `${basePath}/layers`;
const fs = require("fs");

const network = NETWORK.eth;

// General metadata for Ethereum
const namePrefix = "Your Collection";
const description = "Remember to replace this description";
const baseUri = "ipfs://NewUriToReplace";

const solanaMetadata = {
  symbol: "YC",
  seller_fee_basis_points: 1000, // Define how much % you want from secondary market sales 1000 = 10%
  external_url: "https://www.youtube.com/c/hashlipsnft",
  creators: [
    {
      address: "7fXNuer5sbZtaTEPhtJ5g5gNtuyRoKkvxdjEjEnPN4mC",
      share: 100,
    },
  ],
};


let layerConfig = [];
let incrementSize = 1;
const files = fs.readdirSync(layersDir);
for (const file of files) {

   let layerObj = {};
   let layersData = [];
  let filePath = `${layersDir}/${file}`;
  const inner_dir = fs.readdirSync(filePath);
  layerObj.growEditionSizeTo = incrementSize;
  for (const sub_dir of inner_dir) {
    let subDirObj = {};
    let subDirPath = `${filePath}/${sub_dir}`;
    let checkDir =  fs.statSync(subDirPath);
    if(checkDir.isDirectory()){
     
       subDirObj.name = file+"/"+sub_dir;
       layersData.push(subDirObj); 
    } 
  }

   layerObj.layersOrder = layersData;
   layerConfig.push(layerObj);
   incrementSize = incrementSize+1;
}
// Read layer folders name 


// If you have selected Solana then the collection starts from 0 automatically

const layerConfigurations = layerConfig;
/*const layerConfigurations = [
   
   {
    growEditionSizeTo: 1,
    layersOrder: [
        { name: "Web Animation/Q 1" },
        { name: "Web Animation/Q 2" },
        { name: "Web Animation/Q 3" },
        { name: "Web Animation/Q 4" },
        { name: "Web Animation/Q 5" },

      
    ],
  },


  {
    growEditionSizeTo: 2,
    layersOrder: [
        { name: "Art/A" },
        { name: "Art/B" },
        { name: "Art/C" },
        { name: "Art/D" },
        { name: "Art/E" },

      
    ],
  },
    


  {
    growEditionSizeTo: 3,
    layersOrder: [
        { name: "PI Trait/A" },
        { name: "PI Trait/B" },
        { name: "PI Trait/C" },
        { name: "PI Trait/D" },
        { name: "PI Trait/E" },
        { name: "PI Trait/F" },
        { name: "PI Trait/G" },

      
    ],
  },

  {
    // Creates an additional 100 artworks
    growEditionSizeTo: 4,
    layersOrder: [
        { name: "Circle/A" },
        { name: "Circle/B" },
        { name: "Circle/C" }      
    ],
  },




  
 
];*/

const shuffleLayerConfigurations = true;

const debugLogs = false;

const format = {
  width: 512,
  height: 512,
  smoothing: false,
};

const gif = {
  export: false,
  repeat: 0,
  quality: 100,
  delay: 500,
};

const text = {
  only: false,
  color: "#ffffff",
  size: 20,
  xGap: 40,
  yGap: 40,
  align: "left",
  baseline: "top",
  weight: "regular",
  family: "Courier",
  spacer: " => ",
};

const pixelFormat = {
  ratio: 2 / 128,
};

const background = {
  generate: true,
  brightness: "80%",
  static: false,
  default: "#000000",
};

const extraMetadata = {};

const rarityDelimiter = " ";

const uniqueDnaTorrance = 10000;

const preview = {
  thumbPerRow: 5,
  thumbWidth: 50,
  imageRatio: format.height / format.width,
  imageName: "preview.png",
};

const preview_gif = {
  numberOfImages: 5,
  order: "ASC", // ASC, DESC, MIXED
  repeat: 0,
  quality: 100,
  delay: 500,
  imageName: "preview.gif",
};

module.exports = {
  format,
  baseUri,
  description,
  background,
  uniqueDnaTorrance,
  layerConfigurations,
  rarityDelimiter,
  preview,
  shuffleLayerConfigurations,
  debugLogs,
  extraMetadata,
  pixelFormat,
  text,
  namePrefix,
  network,
  solanaMetadata,
  gif,
  preview_gif,
};
